.class public Lcom/mryusefalhamde/StubApp;
.super Landroid/app/Application;
.source "StubApp.java"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "ark"

    const-string v1, "com.mryusefalhamde.StubApp"

    invoke-static {v0, v1}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string v0, "mryusefalhamde"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method public static native callBoolean(ILjava/lang/Object;[Ljava/lang/Object;)Z
.end method

.method public static native callByte(ILjava/lang/Object;[Ljava/lang/Object;)B
.end method

.method public static native callChar(ILjava/lang/Object;[Ljava/lang/Object;)C
.end method

.method public static native callDouble(ILjava/lang/Object;[Ljava/lang/Object;)D
.end method

.method public static native callFloat(ILjava/lang/Object;[Ljava/lang/Object;)F
.end method

.method public static native callInt(ILjava/lang/Object;[Ljava/lang/Object;)I
.end method

.method public static native callLong(ILjava/lang/Object;[Ljava/lang/Object;)J
.end method

.method public static native callObject(ILjava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native callShort(ILjava/lang/Object;[Ljava/lang/Object;)S
.end method

.method public static native callVoid(ILjava/lang/Object;[Ljava/lang/Object;)V
.end method

.method public static native loadDexFromFactory(Ljava/lang/ClassLoader;)V
.end method

.method public static native nativeInstantiateActivity(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;
.end method

.method public static native nativeInstantiateApplication(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/app/Application;
.end method

.method public static native nativeInstantiateProvider(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/content/ContentProvider;
.end method

.method public static native nativeInstantiateReceiver(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;
.end method

.method public static native nativeInstantiateService(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;
.end method


# virtual methods
.method protected native attachBaseContext(Landroid/content/Context;)V
.end method

.method public native onCreate()V
.end method
